package com.example.ganaplayer;

import android.content.Context;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.provider.MediaStore;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;


import com.example.ganaplayer.databinding.ActivityMainBinding;
import com.example.ganaplayer.databinding.SonglistViewBinding;
import com.example.ganaplayer.databinding.SonglistViewLayoutBinding;

import java.io.IOException;
import java.security.cert.Extension;
import java.util.ArrayList;
import java.util.zip.Inflater;

/**
 * A simple {@link Fragment} subclass.
 *
 * create an instance of this fragment.
 */
public class SongListFragment extends Fragment{
    ActivityMainBinding binding;

    ListView listView;
    ArrayList<Song> songlist;
    MediaPlayer player;
    TextView textView;


    SongParse songParse;





    SongListFragment(ArrayList<Song> songlist, MediaPlayer player, TextView textView){
       this.songlist = songlist;
       this.player = player;
       this.textView = textView;



    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
            View v = inflater.inflate(R.layout.songlist_view,null);
            listView = v.findViewById(R.id.listviewSong);
            myAdapter adapter = new myAdapter(getContext());
            listView.setAdapter(adapter);
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    Song song = songlist.get(position);
//                    Toast.makeText(getContext(), "song name " + song.name, Toast.LENGTH_SHORT).show();
                    songParse.songParseFromSonglistFragment(position);

                }
            });

            return v;
    }


    class  myAdapter extends ArrayAdapter{
        SonglistViewLayoutBinding listbinding;


        public myAdapter(@NonNull Context context) {
            super(context, R.layout.songlist_view_layout,songlist);
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            listbinding = SonglistViewLayoutBinding.inflate(getLayoutInflater());
                Song song = songlist.get(position);
                listbinding.TvSongName.setText(song.name);

                return  listbinding.getRoot();


        }
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        songParse = (SongParse) context;

    }

    public interface  SongParse {
        public void songParseFromSonglistFragment(int CurrrentPotions);

    }
}