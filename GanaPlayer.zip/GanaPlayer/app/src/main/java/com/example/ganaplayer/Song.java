package com.example.ganaplayer;

import java.io.Serializable;

public class Song implements Serializable {
    Long id;
    String name ;
    String path;

    Song(){

    }
    public Song(Long id, String name, String path) {
        this.id = id;
        this.name = name;
        this.path = path;
    }

    public String getPath() {
        return path;
    }
}
