package com.example.ganaplayer;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

import android.app.Activity;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.Toast;

import com.example.ganaplayer.databinding.ActivityMainBinding;

import java.io.IOException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements SongListFragment.SongParse {
    ActivityMainBinding binding;
  androidx.fragment.app.Fragment fragmentList[] = new Fragment[2];
  ArrayList<Song> songlist;
  ListView listView;
  MediaPlayer player;
  int count=0;

 int  CurrentPostion=0;






    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       binding =  ActivityMainBinding.inflate(getLayoutInflater());
       setContentView(binding.getRoot());
       songlist = new ArrayList<>();
        getmp3songs();
        player = new MediaPlayer();

        SongListFragment fragmentSonglist=new SongListFragment(songlist,player,binding.CurrentName);
       fragmentList[0] = fragmentSonglist;
       fragmentList[1] = new favFragment();

        binding.tabBar.setupWithViewPager(binding.viewpager);
        binding.viewpager.setAdapter(new MyFragmentAdapter());
        binding.IBnextbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playNext();
            }
        });
        binding.IVpreviousBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playPrevious();
            }
        });
        binding.playbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(count==0){
                    player.pause();
                    binding.playbtn.setImageResource(R.drawable.play_btn);
                    count=1;

                }else{
                    player.start();
                    binding.playbtn.setImageResource(R.drawable.pause_btn);
                    count=0;
                }
            }
        });









        player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {

            }
        });

        binding.seekbar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {

            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });












    }
    void getmp3songs(){
        Uri uri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        Cursor cursor = managedQuery(uri,null,null,null,null);
        if(cursor!= null ){
            if(cursor.moveToNext()){
                do {


//                    if(songName.endsWith("mp3")){
                    long id = cursor.getLong(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID));
                    String name = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME));
                    String genre = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.GENRE));
                    String length = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION));
                    String path = cursor.getString(cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA));


                    Song song = new Song(id,name,path);


                    songlist.add(song);

                    Log.e("song name ","id: "+id+"\nsong name :"+name+"\n genre "+genre+"\nsong duration:"+length);
//                    }

                }while(cursor.moveToNext());
            }
            cursor.close();
        }
    }




    class MyFragmentAdapter extends FragmentPagerAdapter{
        MyFragmentAdapter(){
            super(getSupportFragmentManager());
        }
        @NonNull
        @Override
        public Fragment getItem(int position) {
            return fragmentList[position] ;
        }

        @Override
        public int getCount() {

            return fragmentList.length ;
        }

        @Nullable
        @Override
        public CharSequence getPageTitle(int position) {
            String title="";

            switch (position){
                case 0: title="Music List"; break;
                case 1 : title ="fav";break;


            }
            return title;
        }
    }

    public void PlaySong(){
        Song song = songlist.get(CurrentPostion);
        binding.playbtn.setImageResource(R.drawable.pause_btn);
        Toast.makeText(this, "Song name"+song.name, Toast.LENGTH_SHORT).show();
        if(player.isPlaying()){
            try {
                player.reset();
                player.setDataSource(song.path);
                player.prepare();
                player.start();
                binding.CurrentName.setText(song.name);
            }catch (Exception e){
                Log.e("excenption in already playing song",""+e);

            }
        }
        else{
            try {
                player.setDataSource(song.path);
                player.prepare();
                player.start();
                binding.CurrentName.setText(song.name);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

        }
    }
   public void playNext(){
        if(CurrentPostion<songlist.size()){
            CurrentPostion +=1;
            PlaySong();
        }

   }
   public void playPrevious(){
       if(CurrentPostion> -1){
           CurrentPostion -=1;
           PlaySong();
       }
   }
    @Override
    public void songParseFromSonglistFragment(int CurrrentPotions) {
        this.CurrentPostion = CurrrentPotions;
        PlaySong();
    }


}